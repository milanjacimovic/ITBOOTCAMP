import React from 'react'

const Emoji = (props)=>{
    return (
        <img src={props.url} alt='dje je slika nestala'></img>
    )
}
export default Emoji