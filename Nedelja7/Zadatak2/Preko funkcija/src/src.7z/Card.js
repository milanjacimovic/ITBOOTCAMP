import React from 'react'
import Emoji from './Emoji'
import Description from './Description'

const Card=(props)=>{
    return(
        <>
        <Description string={props.string}></Description>
        <Emoji url={props.url}></Emoji>
        </>
    )
}

export default Card