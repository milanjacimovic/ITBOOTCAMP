import React from 'react'

const Description=(props)=>{
    return (
        <p>{props.string}</p>
    )
}

export default Description