import React from 'react';
import './App.css';
import Card from './Card';


function App() {
  return (
   <Card string='Ajooooj' url='https://cdn.shopify.com/s/files/1/1061/1924/products/Beer_Emoji_large.png?v=1571606035'></Card>
  );
}

export default App;
