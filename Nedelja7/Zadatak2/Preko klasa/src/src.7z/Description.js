import React from 'react'

class Description extends React.Component{
    render(){
    return (
        <p>{this.props.string}</p>
    )
}
}
export default Description