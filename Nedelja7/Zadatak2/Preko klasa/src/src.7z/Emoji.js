import React from 'react'

class Emoji extends React.Component {
    render() {
        return (
            <img src={this.props.url} alt='dje je slika nestala'></img>
        )
    }
}
export default Emoji