import React from 'react'
import Emoji from './Emoji'
import Description from './Description'

class Card extends React.Component{
    render(){
    return(
        <>
        <Description string={this.props.string}></Description>
        <Emoji url={this.props.url}></Emoji>
        </>
    )
}
}
export default Card