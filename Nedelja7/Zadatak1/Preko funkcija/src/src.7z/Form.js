import React from 'react'
import './Form.css'
const Form = (props) => {
    let { string } = props
    return (< form className="form" >
        <input type="text" placeholder="Unesite teks"></input>
        <button>{string}</button>
    </form >)
}

export default Form