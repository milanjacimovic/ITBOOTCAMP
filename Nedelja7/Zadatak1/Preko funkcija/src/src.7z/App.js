import React from 'react';
// import logo from './logo.svg';
import './App.css';
import Form from './Form';

function App() {
  return (
   <Form string='Klikni'></Form>
  );
}

export default App;
