import React from 'react'
import './Form.css'
class Form extends React.Component{
    render(){
        return(
            <form className="form">
                <input type="text" placeholder="Unesite tekst"></input>
        <button>{this.props.string}</button>
            </form>
        )
    }
}

export default Form

