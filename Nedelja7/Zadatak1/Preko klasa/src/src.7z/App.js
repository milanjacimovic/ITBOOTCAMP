import React from 'react';
import './App.css';
import Form from './Form';

function App() {
  return (
   <Form string='Klikni'></Form>
  );
}

export default App;
